<!-- search -->
<form class="search form-inline" method="get" action="<?php echo home_url(); ?>" role="search">
	<div class="form-group">
		<input class="search-input form-control" type="search" name="s" placeholder="To search, type and hit enter.">
	</div>
	<button class="search-submit btn btn-default" type="submit" role="button">Search</button>
</form>
<!-- /search -->
