(function($){



	$('#product-slide').slick({
		  infinite: true,
		  slidesToShow: 3,
		  slidesToScroll: 3
	});
	$('#banners-package').slick({
		dots: false,
		arrows: true,
		autoplay: true,
		swipeToSlide: true,
	});

	$('#image-slider').slick({
		dots: false,
		arrows: true,
		autoplay: true,
		swipeToSlide: true,
	});





}(jQuery));
