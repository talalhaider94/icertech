<?php if( get_field('body_banner') ): ?>

  	  <img class="img-responsive img--full-width" src="<?php the_field('body_banner'); ?>" alt="banner-image" />

<?php endif; ?>
