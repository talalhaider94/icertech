=== WooCommerce Dynamic Pricing ===
Contributors: lcuasstark
Donate link: http://lucasstark.com/donate
Tags: woocommerce, price
Requires at least: 3.0
Tested up to: 3.3

WooCommerce Dynamic Pricing

== Installation ==

1. Upload the folder 'woocommerce-pricing' to the '/wp-content/plugins/' directory

2. Activate 'WooCommerce Dynamic Pricing' through the 'Plugins' menu in WordPress

== Usage ==

1. Edit a product and look for the 'Dynamic Pricing' tab. 

2. Configure the dynamic pricing options for your product.  Enter numerical values in the From and To fields.  To allow an unlimited number, use the * symbol.